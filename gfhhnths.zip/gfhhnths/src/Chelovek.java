public abstract class Chelovek implements Deistvie{
        public int name;
    public Chelovek(int name) {
        this.name = name;
    }

    public Chelovek() {

    }

    public void igraet(){
        System.out.println("Brosaet myach");
    }
        public void kormit(){
        System.out.println("nasipaet korm");
    }
    }

