public abstract class Dog implements Deistvie {
    public int NameDog;
    public Dog(int NameDog){
        this.NameDog = NameDog;
    }
    public void gavkaet(){
        System.out.println("gav-gav");
        System.out.println("rrrr");
    }
    public void radost(){
        System.out.println("vilaet");
        System.out.println("richit");
        System.out.println("lizet");
        }
    }