public class vse {
    public static void main(String[] args){
       Chelovek Bob = new Chelovek() {
           @Override
           public void showIhfo() {

           }
       };
        instruments instruments2 = new Strunnie(2);
        instruments1.showInfo();
        instruments2.showInfo();
}

