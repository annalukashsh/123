public interface Deistvie {
    public void showIhfo();
}
