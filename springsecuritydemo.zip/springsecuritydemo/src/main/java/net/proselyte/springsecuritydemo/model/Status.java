package net.proselyte.springsecuritydemo.model;

public enum Status {
    ACTIVE, BANNED
}