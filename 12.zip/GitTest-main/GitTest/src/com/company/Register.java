package com.company;

import java.util.ArrayList;
import jdk.internal.org.objectweb.asm.tree.InsnList;

import java.util.ArrayList;

public class   Register extends User {
    ArrayList<User> registrated = new ArrayList<>();

    public void Reg(String name) {
        User new_user = new User();
        new_user.SetName(name);

    }

    {
        String pass = "";


        String poss = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuWwXxYyZz1234567890!@#$%^&*_-+=':;";
        for (int i = 0; i < poss.length(); i++) {
            pass += poss.charAt((int) Math.random() * (((poss.length() - 0)) + 0));
        }
    }
}






