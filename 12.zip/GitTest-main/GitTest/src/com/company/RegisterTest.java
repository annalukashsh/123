package com.company;

import static org.junit.jupiter.api.Assertions.*;

class RegisterTest {

    @org.junit.jupiter.api.Test
    void reg()
    {
        System.out.println("111");
    }

    @org.junit.jupiter.api.Test
    void testReg()
    {
System.out.println("1");
    }

    @org.junit.jupiter.api.Test
    void del()
    {
System.out.println("222");
    }
}