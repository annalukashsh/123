package com.company;

public class User
{
    private String name;
    private String password;

    public String GetPassword() {
        return password;
    }

    public void SetPassword(String password) {
        this.password = password;
    }

    public void SetName(String name) {
    }
}
