package com.company;


public class Main extends User {
    public static void ad(String name, String pass){
        Main.ad(name,pass);}

    public static void main(String[] args) {
        Main main = new Main();



        Register R1= new Register();

        R1.Reg("Tim");
        System.out.println(R1.registrated.get(0).GetPassword());
        R1.Reg("Eva");
        R1.Reg("Viktor");
        R1.Reg("Artem");
        R1.Reg("Donni");
        R1.Reg("Rino");
        
    }
    }
