import java.util.Scanner;

class moderator extends Usual_user {
    void del_us(){ Usual_user.del();}
    moderator mod = new moderator();

    static void write_comm(){
        System.out.println("Напишите коментарий:");
        Scanner m = new Scanner(System.in);
        String c = m.next();
    }
    static void del(){
        System.out.println("Вы хотите удалить коментарий?");
        System.out.println("Да");
        System.out.println("Нет");
        Scanner m = new Scanner(System.in);
        int choose = m.nextInt();
        switch (choose){
            case 1:
                
                System.out.println("Сообщение удалено");
                break;
            case 2:
                System.out.println(c);

        }}
}

