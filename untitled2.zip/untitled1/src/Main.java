
public class Main extends User {
    public void write_u(){
        Usual_user.write_comm();
    }
    public void write_a(){
        admin.write_comm();
    }
    public void write_m(){
       moderator.write_comm();
    }
    public void del_u(){
        Usual_user.del();
    }
    public void del_a(){
        admin.del();
    }
    public void del_m(){
        moderator.del();
    }
    public static void red(){
        Usual_user.red();
    }
    public void add(String name,String password,String role){
        admin.add(name,password,role);
    }
    public void cr (String name,String password,String role){
        admin.cr(name,password,role);
    }


    public static void main(String[] args)
    {
       Main main = new Main();



       Register R1= new Register();

        R1.Reg("Elisa","moderator");
        System.out.println(R1.registered.get(0).);
        R1.Reg("Anton","user");
        R1.Reg("Herman","user");
        R1.Reg("Moonton","user");
        R1.Reg("Elfi1","moderator");
        R1.Reg("Toro","moderator");
        R1.Reg("Uri","admin");
        R1.Reg("Tifon","user");


main.write_u();

        main.red();

        main.del_u();
        main.del_m();
    }
}
