public class adminImpl extends admin {

}
