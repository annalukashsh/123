import java.util.ArrayList;


public class Register extends User {
     ArrayList<User> registered =new ArrayList<>();

    public void Reg(String name,String role)
    {
        User new_user= new User();
        new_user.SetName(name);
        new_user.SetRole(role);
        boolean add = registered.add(new_user);


    }
    public void Reg1(String name,String role) {
        User new_user = new User();

        String pass = "";


        String poss = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuWwXxYyZz1234567890!@#$%^&*_-+=':;";
        for (int i = 0; i < poss.length(); i++) {
            pass += poss.charAt((int) Math.random() * (((poss.length() - 0)) + 0));
        }

    }
}
