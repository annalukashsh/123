package com.company;

import java.util.ArrayList;

public class Register
{
    ArrayList<User> registrated =new ArrayList<>();

    public void reg(String name,String pass)
        {

    }
    public void reg(String name)
    {

    }
    public void del(String name,String pass)
    {

    }
}
